<?php 
	/*Update credentials*/
	define('EMAIL', 'add-email-address');
	define('PASS', 'add-password');
	
 ?>