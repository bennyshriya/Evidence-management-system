
<?php

require("includes/common.php");

$value = $_SESSION['value'];
$_SESSION['ccaseid'] = $_POST['ccaseid'];
$ccaseid = $_SESSION['ccaseid'];

// Retrieve the values
if (!empty($_POST['ccaseid'])) {
    $ccaseid = $_POST['ccaseid'];
    $cdate = $_POST['cdate'];
    $cstatus = $_POST['cstatus'];
    $caddress = $_POST['caddress'];

    $cases_query = "INSERT INTO CASES (CASE_ID, DATE, STATUS, ADDRESS) VALUES ('$ccaseid','$cdate','$cstatus','$caddress')";

    if ($cases_submit = mysqli_query($con, $cases_query)) {
        echo "<script>if(confirm('Insertion Successful! Proceed Next -->')){document.location.href='newhome.php'};</script>";
    } else {
        $error_message = "Error: " . mysqli_error($con);
        echo "<script>alert('$error_message'); document.location.href='insertcase.php';</script>";
    }
}
?>
