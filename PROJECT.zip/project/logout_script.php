<?php

require("includes/common.php");

session_start();
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}

// Assuming $value is still needed for some reason
$value = $_SESSION['value'];

// Remove the code related to the 'ACCESSLOGS' table
// $accesslog = "UPDATE ACCESSLOGS SET LOGGEDOUT=NOW() WHERE ID = '$value'";
// $run_accesslog = mysqli_query($con, $accesslog) or die(mysqli_error($con));

session_destroy();
header('location: index.php');

?>
