<?php
	$con = mysqli_connect("localhost", "root", "Beldar@123", "forensic",'4306')or die("Common.php error");
	session_start();
	echo "Connected Successfully!.."
?>