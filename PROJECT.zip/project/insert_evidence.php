<?php
require("includes/common.php");

if (!isset($_SESSION['email'])) {
    header('location: index.php');
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input data for evidence table
    $labId = mysqli_real_escape_string($con, $_POST["labid"]);
    $caseId = mysqli_real_escape_string($con, $_POST["caseid"]);
    $processingMethod = mysqli_real_escape_string($con, $_POST["processingmethod"]);

    // Perform form validation for evidence table
    if (empty($labId) || empty($caseId) || empty($processingMethod)) {
        $message = "All fields for evidence are required.";
        echo "<script>if(confirm('$message')){document.location.href='insert_evidence.php'};</script>";
        exit;
    }

    // Insert data into the EVIDENCE table
    $queryEvidence = "INSERT INTO evidence (LAB_ID, CASE_ID, PROCESSING_METHOD) VALUES ('$labId', '$caseId', '$processingMethod')";

    if (mysqli_query($con, $queryEvidence)) {
        echo "<script>alert('Evidence insertion successful!');</script>";
    } else {
        $message = "Couldn't insert evidence values! Please try again.";
        echo "<script>alert('$message');</script>";
    }
}
?>

<!-- HTML Form for Inserting Evidence -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Evidence</title>
</head>
<body>

    <h2>Insert Evidence</h2>

    <form action="insert_evidence.php" method="POST">
    
        <label for="labid">LAB_ID</label>
        <input type="number" name="labid" required>
        <br><br>

        <label for="caseid">CASE_ID</label>
        <input type="text" name="caseid" required>
        <br><br>

        <label for="processingmethod">PROCESSING_METHOD</label>
        <input type="text" name="processingmethod" required>
        <br><br>

        <button type="submit" name="insert">Insert Evidence</button>
    </form>

</body>
</html>