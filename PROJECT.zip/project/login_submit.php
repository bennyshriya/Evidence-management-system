<?php
require("includes/common.php");

$email = $_POST['e-mail'];
$password = $_POST['password'];

// Check if the connection is successful
if ($con) {
    $query = "SELECT ID, NAME, EMAIL FROM USERS WHERE EMAIL=? AND password=?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "ss", $email, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $num = mysqli_num_rows($result);

    if ($num == 0) {
        header('location: failed.php');
    } else {
        $row = mysqli_fetch_array($result);

        $_SESSION['email'] = $row['EMAIL'];
        $_SESSION['user_id'] = $row['ID'];
        $_SESSION['name'] = $row['NAME'];

        $userValue = $_SESSION['user_id'];  // Use the user_id as the value for the USER column

        $accesslog = "INSERT INTO ACCESSLOGS(USER, LOGGEDIN) VALUES (?, NOW())";
        $stmt_accesslog = mysqli_prepare($con, $accesslog);

        if ($stmt_accesslog) {
            mysqli_stmt_bind_param($stmt_accesslog, "i", $userValue);
            $run_accesslog = mysqli_stmt_execute($stmt_accesslog);

            if ($run_accesslog) {
                header('location: success.php');
            } else {
                // Handle the case where the query fails
                die("Error in access log query execution: " . mysqli_stmt_error($stmt_accesslog));
            }
        } else {
            // Handle the case where the prepare statement fails
            die("Error in preparing access log statement: " . mysqli_error($con));
        }
    }
} else {
    // Handle the case where the connection is not successful
    die("Connection failed: " . mysqli_connect_error());
}
?>
